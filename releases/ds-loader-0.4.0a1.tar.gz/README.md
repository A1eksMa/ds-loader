# ds-loader

Оркестратор процесса обновления данных для [`ds`](https://github.com/A1eksMa/ds).

Раннер за тик прогоняет упорядоченный список **стадий** (`config.stages`). Реализованы две:

- **`ingest`** — мониторит директорию, куда источники кладут выгрузки, для каждого нового
  файла вызывает `ds load`, затем архивирует файл;
- **`publish`** — вызывает `ds get` и раскладывает результат как `data/<Source>.js` +
  `data/manifest.js` для [`ds-webui`](https://github.com/A1eksMa/ds-webui) (идемпотентно:
  неизменившиеся файлы не переписываются). Формат — [`docs/reference/publish-output.md`](docs/reference/publish-output.md).

На будущее — стадии жизненного цикла и сборки (см. [`docs/roadmap/`](docs/roadmap/)).

С ядром `ds` связан **только через CLI** (argv + код возврата + stdout). Кода ядра не
импортирует.

## Технические требования

Те же, что у `ds`: только стандартная библиотека Python (`>= 3.9`), офлайн, без сетевых
портов, функциональный стиль, чистая архитектура (domain / ports / adapters / app).

## Установка и запуск

```bash
pip install -e .

# один проход (для отладки / cron)
ds-loader run --once --update-dir /data/upd --db /data/data.db

# приём + публикация для ds-webui (нужен "stages": ["ingest","publish"] в конфиге)
ds-loader run --once --config config.json

# бесконечный цикл с интервалом опроса из конфига
ds-loader run --config config.json
```

В режиме цикла лог идёт в stderr: баннер с конфигом на старте, подробности по каждому
обработанному файлу, короткий «жду данные …» в простое, `Ctrl-C` — чистый выход с итогом.
`--verbose` — детальнее, `--quiet` — только ошибки. Подробно — [`docs/reference/cli.md`](docs/reference/cli.md).

Без установки: `PYTHONPATH=/opt/ds-loader python3 -m src.cli.main run --once --update-dir ...`.

Для машины без git — архив кода одним файлом: [`releases/`](releases/) (`ds-loader-<version>.tar.gz`).

Параметры берутся из `--config` (JSON, см. [`config.example.json`](config.example.json)),
поверх — флаги CLI. `update_dir` обязателен (в конфиге или через `--update-dir`).

**Без pip** (оба проекта — чекауты): в конфиге `"ds_command": ["python3","-m","src.cli.commands"]`
и `"ds_pythonpath": "/opt/ds"` — иначе `PYTHONPATH` загрузчика затенит `src` ядра. Подробно —
[`docs/reference/cli.md`](docs/reference/cli.md) → «Запуск без pip».

## Что делает приём (стадия `ingest`)

За один проход:

1. читает имена файлов в `update_dir`, разбирает их (`<source>_YYYY-MM-DD_HH-MM-SS_<µs>.json`);
2. упорядочивает: по метке времени (старые → новые), при равенстве — по имени источника;
3. по одному файлу:
   - если файл уже в журнале — просто доносит его в архив (крах-безопасность);
   - если файл ещё дописывается (`mtime` моложе `stable_after_seconds`) — пропуск до следующего прохода;
   - иначе: `ds --db <db> load <sources_dir>/<source> <file> --dt <unix>` (метка из имени, UTC);
   - при успехе — запись в журнал, затем перемещение в `archive/<source>/<source>_YYYY-MM-DD_HH-MM-SS.json`;
   - при ошибке `ds` или битой метке — в `quarantine/<source>/` + `.err`-сайдкар.

`ds` **не идемпотентен**, поэтому «загрузить ровно один раз» держится на журнале
(`ledger_path`, JSONL) с ключом «имя файла + sha256 содержимого». Остаётся крошечное окно
(крах между `commit` в `ds load` и записью журнала) — см.
[`docs/explanation/exactly-once.md`](docs/explanation/exactly-once.md).

## Что делает публикация (стадия `publish`)

Требует `webui_data_dir` (каталог `data/` рядом с `index.html` `ds-webui`). За один проход:

1. `ds get [--preset <webui_preset>]` — свёрнутое состояние источников голым JSON;
2. на каждый источник — `<webui_data_dir>/<Source>.js` (`window.DS.sources[...] = {meta, data}`);
3. сборка `<webui_data_dir>/manifest.js` (`window.DS_MANIFEST` — индекс со свежестью).

Идемпотентно: отпечаток источника (`gen_max_cnt` + показатели) хранится в
`publish_state_path`; неизменившийся `<Source>.js` не переписывается. Формат и ограничение
`db_max_cnt = gen_max_cnt` (v1) — [`docs/reference/publish-output.md`](docs/reference/publish-output.md).

## Документация

- [`docs/README.md`](docs/README.md) — карта
- [`docs/explanation/`](docs/explanation/) — зачем, модель стадий, exactly-once
- [`docs/reference/`](docs/reference/) — конфиг, CLI, формат имён, раскладка архива, вывод `publish`
- [`docs/roadmap/`](docs/roadmap/) — жизненный цикл / сборка / честный `db_max_cnt`

## Разработка

```bash
./run_tests.sh          # pytest в образе Python 3.9.20
python -m pytest -q     # локально
```

См. [`CONTRIBUTING.md`](CONTRIBUTING.md).

## Лицензия

MIT — см. [`LICENSE`](LICENSE).
